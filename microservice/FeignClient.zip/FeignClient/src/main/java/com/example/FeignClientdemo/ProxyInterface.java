package com.example.FeignClientdemo;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "microservice",url = "http://localhost:8081")
public interface ProxyInterface {
    @GetMapping("/get")
    public String getbyfeign();
}
